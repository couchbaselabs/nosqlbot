from couchbase.client import Server, Bucket
